module.exports = {
  branches: 95,
  lines: 95,
  functions: 95,
  statements: 95,
}
