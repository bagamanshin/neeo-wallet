# Development

Several files which are needed for developing on(!) MetaMask.

Usually each files contains information about its scope / usage.