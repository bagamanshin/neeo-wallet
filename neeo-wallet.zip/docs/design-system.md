# MetaMask Design System

A design system is a series of components that can be reused in different combinations. Design systems allow you to manage design at scale.

Design System [Figma File](https://www.figma.com/file/aWgwMrzdAuv9VuPdtst64uuw/Style-Guide?node-id=211%3A0)
