export { default } from './confirm-page-container-summary.component'
