export { default } from './gas-modal-page-container.container'
