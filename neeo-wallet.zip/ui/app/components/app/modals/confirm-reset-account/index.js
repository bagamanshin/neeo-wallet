export { default } from './confirm-reset-account.container'
