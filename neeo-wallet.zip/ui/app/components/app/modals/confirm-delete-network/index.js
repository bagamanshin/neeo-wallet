export { default } from './confirm-delete-network.container'
