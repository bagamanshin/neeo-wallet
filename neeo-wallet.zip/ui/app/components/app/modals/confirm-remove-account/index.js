export { default } from './confirm-remove-account.container'
