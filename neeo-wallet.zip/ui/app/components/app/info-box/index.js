import InfoBox from './info-box.component'

export default InfoBox
