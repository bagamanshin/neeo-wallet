export { default } from './modal.component'
export { default as ModalContent } from './modal-content'
