export { default } from './contact-list.component'
