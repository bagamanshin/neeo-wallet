export { default } from './recipient-group.component'
