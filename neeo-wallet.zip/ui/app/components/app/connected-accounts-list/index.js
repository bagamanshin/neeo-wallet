export { default } from './connected-accounts-list.component'
