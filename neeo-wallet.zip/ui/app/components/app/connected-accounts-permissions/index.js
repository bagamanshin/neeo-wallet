export { default } from './connected-accounts-permissions.component'
